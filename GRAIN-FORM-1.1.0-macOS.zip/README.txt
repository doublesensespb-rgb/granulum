GRAIN FORM for macOS (Apple Silicon + Intel)

1. Copy "GRAIN FORM.vst3"      to  /Library/Audio/Plug-Ins/VST3/
   Copy "GRAIN FORM.component" to  /Library/Audio/Plug-Ins/Components/
2. Open Terminal and run (removes the "downloaded from internet" block):
   sudo xattr -dr com.apple.quarantine "/Library/Audio/Plug-Ins/VST3/GRAIN FORM.vst3" "/Library/Audio/Plug-Ins/Components/GRAIN FORM.component"
3. Rescan plugins in your DAW.
